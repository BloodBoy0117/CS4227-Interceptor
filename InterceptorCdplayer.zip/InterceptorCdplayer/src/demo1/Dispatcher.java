package demo1;

public interface Dispatcher {
    public void dispatch();
    public void registerDispatcher(Interceptor interceptor);
}
