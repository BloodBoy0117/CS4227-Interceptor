package demo1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ConcreteDispatcher implements Dispatcher {
    private static List<Interceptor> interceptors;
    private Context context = new Context();
    // 注册interceptors
    static {
        interceptors = new ArrayList<Interceptor>();
        interceptors.add((Interceptor) new ConcreteInterceptor());
    }
    public void dispatch() {
        Iterator<Interceptor> iterator = interceptors.iterator();
        while (iterator.hasNext()) {
            Interceptor tmp = iterator.next();
            tmp.interceptor(context);
        }
    }
    public void registerDispatcher(Interceptor interceptor) {
        synchronized (interceptors) {
            interceptors.add(interceptor);
        }
    }
}
