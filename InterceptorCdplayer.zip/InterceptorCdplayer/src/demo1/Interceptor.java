package demo1;

public interface Interceptor {
    public void interceptor(Context context);
}
