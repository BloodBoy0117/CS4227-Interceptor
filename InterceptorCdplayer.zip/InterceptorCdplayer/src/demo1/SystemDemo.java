package demo1;

public class SystemDemo {
    private Dispatcher dispatcher = new ConcreteDispatcher();
    /**
     * 模拟一个框架或者一个具体的系统，此方法是使用interceptor的切入点
     */
    public void doWork() {
        // 做其他的事情
        dispatcher.registerDispatcher(new ConcreteInterceptor());
        dispatcher.registerDispatcher(new ConcreteInterceptor());
        dispatcher.dispatch();
        // 做其他的事情
    }
}
