package demo1;

public class StartSystem {
    /**
     * @param args
     */
    public static void main(String[] args) {
        new SystemDemo().doWork();
    }
}
