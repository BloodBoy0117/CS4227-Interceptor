package demo1;

public class ConcreteInterceptor implements Interceptor{
    @Override
    public void interceptor(Context context) {
        System.out.println("intercept here WOW!!!");
    }
}
