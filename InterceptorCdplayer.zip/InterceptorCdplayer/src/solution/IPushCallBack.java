package solution;

public interface IPushCallBack {
    public void notifyButtonPushed(Button b); //按钮点击发送回调通知
}
