package demo;
//1
public interface Filter {
    public void execute(String request);
}
