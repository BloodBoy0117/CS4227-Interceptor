package demo;
//3
public class Target {
    public void execute(String request){
        System.out.println("Executing request: " + request);
    }
}
